﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4._2
{
    internal class Program
    {
        /*Перемножить матрицы E и P, где Е – единичная матрица, P – пользовательская матрица. 
         *Перемножение реализовать поэлементно.*/

        static void Main(string[] args)
        {
            Console.Write("Введите размерность матрицы: ");
            int n = int.Parse(Console.ReadLine());

            // Создание единичной матрицы
            int[,] E = new int[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (i == j)
                    {
                        E[i, j] = 1;
                    }
                }
            }

            // Заполнение пользовательской матрицы
            int[,] P = new int[n, n];
            Console.WriteLine("Введите элементы матрицы P:");
            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();
                int[] row = input.Split(' ').Select(int.Parse).ToArray();
                for (int j = 0; j < n; j++)
                {
                    P[i, j] = row[j];
                }
            }

            // Перемножение матриц поэлементно
            int[,] result = new int[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    result[i, j] = E[i, j] * P[i, j];
                }
            }

            Console.WriteLine("Матрица E:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(E[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            // Вывод результата на консоль
            Console.WriteLine("Результат перемножения матриц:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(result[i, j] + " ");
                }
                Console.WriteLine();
            }

        }
    }
}
