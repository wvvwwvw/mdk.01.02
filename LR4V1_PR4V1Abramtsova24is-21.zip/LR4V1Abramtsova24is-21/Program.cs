﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Определить количество различных чисел в одномерном массиве.*/

            // Выводим сообщение пользователю, чтобы он ввел элементы массива через пробел
            Console.Write("Введите элементы массива через пробел: ");

            // Считываем строку, которую ввел пользователь
            string input = Console.ReadLine();

            // Разбиваем строку на подстроки по пробелам, парсим каждую подстроку в целое число и создаем массив из этих чисел
            int[] arr = input.Split(' ').Select(int.Parse).ToArray();

            // Считаем количество уникальных элементов в массиве и выводим результат на экран
            int distinctCount = arr.Distinct().Count();
            Console.WriteLine($"Количество различных чисел в массиве: {distinctCount}");
        }
    }
}
