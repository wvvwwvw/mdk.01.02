﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace znaki
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Вводится знак препинания. Ответить названием этого знака препинания.*/

                Console.Write("Введите знак препинания: ");
                char punctuation = Console.ReadKey().KeyChar;

                switch (punctuation)
                {
                    case '.': Console.WriteLine("\nТочка"); break;
                    case ',': Console.WriteLine("\nЗапятая"); break;
                    case ';': Console.WriteLine("\nТочка с запятой"); break;
                    case ':': Console.WriteLine("\nДвоеточие"); break;
                    case '!': Console.WriteLine("\nВосклицательный знак"); break;
                    case '?': Console.WriteLine("\nВопросительный знак"); break;
                    case '-': Console.WriteLine("\nТире"); break;
                    case '/': Console.WriteLine("\nСлэш"); break;
                    default: Console.WriteLine("\nНеизвестный знак"); break;
                }
            
        }
    
    }
}
