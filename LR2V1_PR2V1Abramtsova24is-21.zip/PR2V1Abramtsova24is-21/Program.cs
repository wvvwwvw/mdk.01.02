﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Даны три фигуры: шар радиуса R, 
             * куб со стороной А и правильная (равносторонняя) пирамида с ребром L. 
             * Вывести на экран название фигуры наибольшего объёма.*/

            Console.Write("Введите радиус окружности : ");
            double R = Convert.ToDouble(Console.ReadLine());
            double Vr = (3.0 / 4.0) * Math.PI * Math.Pow(R, 3);

            Console.Write("Введите сторону куба : ");
            double A = Convert.ToDouble(Console.ReadLine());
            double Va = Math.Pow(A, 3);

            Console.Write("Введите ребро пирамиды : ");
            double L = Convert.ToDouble(Console.ReadLine());
            double Vl = (1.0 / 3.0) * Math.Pow(L, 2) * Math.Sqrt(3);

            if (Vr > Va && Vr > Vl) 
            {
                Console.WriteLine("Наибольший объем у шара: ");
                Console.WriteLine(Math.Round(Vr, 2));  
            }

            else if(Va > Vr && Va >  Vl) 
            {
                Console.WriteLine("Наибольший объем у куба: ");
                Console.WriteLine(Math.Round(Va, 2));
            }

            else 
            {
                Console.WriteLine("Наибольший объем у пирамиды: ");
                Console.WriteLine(Math.Round(Vl, 2));
            }



        }
    }
}
