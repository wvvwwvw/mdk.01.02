﻿using System;
using System.IO;

class Program
{
    /*Составить программу, которая считывает из текстового файла предложения и выводит их 
     *в обратном порядке в консоль. */

    static void Main(string[] args)
    {
        /*Составить программу, которая считывает из текстового файла предложения и выводит их в обратном порядке в консоль.*/

        // открытие файла для чтения
        using (StreamReader reader = new StreamReader("ffile.txt"))
        {
            // считывание содержимого файла в массив строк
            string[] sentences = reader.ReadToEnd().Split(new char[] { '.', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);

            // вывод предложений в обратном порядке в консоль
            for (int i = sentences.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(sentences[i].Trim());
            }
        }
    }

}