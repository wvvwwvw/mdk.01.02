﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR5V1Abramtsova24is_21
{
    internal class Program
    {
        /*1. Подсчитать, сколько букв «о» содержится в тексте. В качестве текста для тестового 
         *примера (тестовых примеров) взять не менее пяти предложений.
         *2. Дана строка str и символ s. Строку str «сжать», удалив из неё каждый второй символ s. 
         *Узнать, сколько символов s осталось в «сжатой» строке. В качестве текста для тестового 
         *примера (тестовых примеров) взять не менее двух предложений.*/

        static void Main(string[] args)
        {
            Console.WriteLine("Введите текст:");
            string text = Console.ReadLine();
            int count = 0;

            foreach (char c in text)
            {
                if (c == 'о')
                {
                    count++;
                }
            }

            Console.WriteLine($"Количество букв 'о' в тексте: {count}");

            Console.WriteLine("Введите строку:");
            string str = Console.ReadLine();
            Console.WriteLine("Введите символ для удаления:");
            char s = Console.ReadKey().KeyChar;
            string compressedStr = "";
            int sCount = 0;

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] != s || i % 2 == 0)
                {
                    compressedStr += str[i];
                }
                else
                {
                    sCount++;
                }
            }

            Console.WriteLine($"\nСжатая строка: {compressedStr}");
            Console.WriteLine($"Количество символов '{s}' в сжатой строке: {sCount}");

            Console.ReadKey();
        }
    }
}
