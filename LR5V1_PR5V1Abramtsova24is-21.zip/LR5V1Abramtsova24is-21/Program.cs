﻿using System;

namespace LR5V1Abramtsova24is_21
{
    internal class Program
    {

        /*Строковому меню предшествует центрированная надпись: «Выберите марку автомобиля 
         *из списка:». Надпись не участвует в «пролистывании» пунктов меню. В качестве пунктов 
         *меню предложить: «Chrysler», «Maybach», «Geely», «Lamborghini», «Lada», «Scoda», 
         *«Mercedes-Benz». Подтверждение выбранного пункта меню реализовать по клавише 
         *«Enter». Выход из меню предусмотреть по нажатии клавиши «Esc». Реализовать 
         *«пролистывание» без перехода через границы (стрелка вверх не работает на элементе с 
         *нулевым индексом и стрелка вниз не работает на элементе с последним индексом).*/


        static void Main(string[] args)
        {
            string[] menuItems = { "Chrysler", "Maybach", "Geely", "Lamborghini", "Lada", "Scoda", "Mercedes-Benz" };
            int selectedItemIndex = 0;

            Console.WriteLine("Выберите марку автомобиля из списка:");

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Выберите марку автомобиля из списка:");

                for (int i = 0; i < menuItems.Length; i++)
                {
                    if (i == selectedItemIndex)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                    Console.WriteLine(menuItems[i]);

                    Console.ResetColor();
                }

                ConsoleKeyInfo key = Console.ReadKey();

                switch (key.Key)
                {
                    case ConsoleKey.UpArrow:
                        if (selectedItemIndex > 0)
                        {
                            selectedItemIndex--;
                        }
                        break;
                    case ConsoleKey.DownArrow:
                        if (selectedItemIndex < menuItems.Length - 1)
                        {
                            selectedItemIndex++;
                        }
                        break;
                    case ConsoleKey.Enter:
                        Console.Clear();
                        Console.WriteLine($"Вы выбрали {menuItems[selectedItemIndex]}");
                        Console.ReadKey();
                        break;
                    case ConsoleKey.Escape:
                        return;
                }
            }
        }
    }
}
