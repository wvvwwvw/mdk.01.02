﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR1V1Abramtsova24is_21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double result = Math.Round((Math.Pow((((((58 * 4 / 15) - Math.Pow(56 * 7 / 24, 1.0 / 5)) / 0.8 * Math.Pow(0.474, 1.0 / 2)) + 2 * 1.0 / 9 * 3 * 2 / 3) / Math.Pow(8 * 3 / 4 * 3 / 5, 1.0 / 3)), 2) - (Math.Pow(Math.Pow(1.0 / 0.13, 3), 1.0 / 5)) * 4 * 7 / 13), 2);
            Console.WriteLine("Результат вычислений: " + result);
        }
    }
}
