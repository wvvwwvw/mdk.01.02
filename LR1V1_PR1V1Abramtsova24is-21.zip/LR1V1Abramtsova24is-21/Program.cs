﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR1V1Abramtsova24is_21
{
    internal class Program
    {
        /*Вычислить гиперболический синус двумя способами, зная следующее соотношение: sinh(x) = e^x - e^(-x)/2*/

        static void Main(string[] args)
        {
            // Запросить у пользователя значение x
            Console.Write("Введите значение x: ");
            double x = double.Parse(Console.ReadLine());

            // Вычислить значение гиперболического синуса двумя способами
            double sinh1 = (Math.Exp(x) - Math.Exp(-x)) / 2;
            double sinh2 = Math.Sinh(x);

            // Вывести результаты на экран
            Console.WriteLine("sinh({0}) = {1} (метод 1)", x, sinh1);
            Console.WriteLine("sinh({0}) = {1} (метод 2)", x, sinh2);
        }
    }
}
