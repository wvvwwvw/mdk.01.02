﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3PR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double e = 2.71828;

            Console.Write("Введите начальное значение x0 : ");
            double x0 = double.Parse(Console.ReadLine());

            Console.Write("Введите конечное значение xk : ");
            double xk = double.Parse(Console.ReadLine());

            Console.Write("Введите шаг delta_x : ");
            double dx = double.Parse(Console.ReadLine());

            Console.Write("Введите угол A : ");
            double alpha = double.Parse(Console.ReadLine());
            alpha = alpha * (Math.PI / 180.0);

            Console.Write("Введите угол B : ");
            double beta = double.Parse(Console.ReadLine());
            beta = beta * (Math.PI / 180.0);

            for(double i = x0; i <= xk; i += dx)
            {
                a = 2.48 + Math.Cos(Math.Pow((Math.Pow(alpha, 2) + beta), (1.0 / 3.0)) + Math.Sin(beta)) / Math.Pow(e, alpha / beta) + Math.Pow(i, 3) + Math.Pow(i, alpha);
                Console.WriteLine("A :");
                Console.WriteLine(Math.Round(a, 2));
            }
            
        }
    }
}
