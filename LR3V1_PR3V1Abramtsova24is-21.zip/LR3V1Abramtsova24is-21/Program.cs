﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3rows
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Запрашиваем у пользователя два числа x и y, а также длину ряда n
            Console.WriteLine("введите 2 числа: x, y");
            double x = Convert.ToDouble(Console.ReadLine());
            double y = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("введите длину ряда");
            double n = Convert.ToDouble(Console.ReadLine());

            // Инициализируем переменную a
            double a = 0;

            // Определяем функцию для вычисления факториала числа m
            double fa(double m)
            {
                if (m == 1) return 1;

                return m * fa(m - 1);
            }

            // Выполняем цикл для вычисления значения переменной a
            for (int i = 1; i <= n; i++)
            {
                // Если номер итерации нечетный, то к переменной a прибавляется сумма трех слагаемых
                if (i % 2 == 1)
                    a += Math.Pow(y, i + 1) + Math.Sin(fa(i + 1)) / Math.Pow(Math.Tan(y), 2 - i) + Math.Pow(Math.Cos(Math.Pow(x, i)), i);
                // Если номер итерации четный, то из переменной a вычитается сумма трех слагаемых
                else
                    a -= Math.Pow(y, i + 1) + Math.Sin(x) / Math.Pow(Math.Tan(y), i) + Math.Pow(Math.Cos(Math.Pow(x, i)), i);

            }

            // Выводим значение переменной a с округлением до двух знаков после запятой
            Console.WriteLine("A :");
            Console.WriteLine(Math.Round(a, 2));
        }
    }
}
